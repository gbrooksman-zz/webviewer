using System;

namespace webviewer.Models
{
    public class Language
    {
        public Language() {}        

        public string Code {get; set;}

        public string Name {get; set;}

    }

}