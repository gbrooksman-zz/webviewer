using System;

namespace webviewer.Models
{
    public class Format
    {
        public Format() {}        

        public string Code {get; set;}

        public string Name {get; set;}

    }

}