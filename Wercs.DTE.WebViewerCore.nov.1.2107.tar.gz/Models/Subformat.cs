using System;

namespace webviewer.Models
{
    public class Subformat
    {
        public Subformat() {}

        public string Code {get; set;}

        public string FormatCode {get; set;}

        public string Name {get; set;}
    }
}