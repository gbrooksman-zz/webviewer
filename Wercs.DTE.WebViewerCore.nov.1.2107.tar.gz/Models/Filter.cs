using System;

namespace webviewer.Models
{
    public class Filter
    {
        public Filter(){}

        public string PropertyName {get; set;}

        public string FieldName {get; set;}

        public string SearchType {get; set;}

        public string SearchText {get; set;}

    }

}